<?php
include_once "../database/Database.php";
include_once "../models/Product.php";

use Database\Database;
use Models\Product;

$database = new Database();
$db = $database->getConnection();

$product = new Product($db);

// Definir el umbral de alerta
$lowStockThreshold = 5;

// Obtener productos con bajo stock
$lowStockProducts = $product->getLowStockProducts(threshold: $lowStockThreshold);
$lowStockCount = count($lowStockProducts);

?>


<div id="sidebar" class="bg-dark">
        <div class="logo text-center py-3">
            <i class="fas fa-boxes text-white"></i>
        </div>
        <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="../views/principal.php" class="nav-link text-white">
                        <i class="fas fa-home"></i> <span>Inicio</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/list_products.php" class="nav-link text-white">
                        <i class="fas fa-list"></i> <span>Listar Productos</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/list_categories.php" class="nav-link text-white">
                        <i class="fas fa-check"></i> <span>Listar Categorías</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/list_suppliers.php" class="nav-link text-white">
                        <i class="fas fa-building"></i> <span>Listar Proveedores</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/register_sale.php" class="nav-link text-white">
                        <i class="fas fa-dollar-sign"></i> <span>Registrar Venta</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/out_of_stock_report.php">
                        <i class="fas fa-exclamation-triangle"></i> <span>Productos Agotados</span> 
                            <?php if ($lowStockCount > 0) { ?>
                                &nbsp;<span class="badge badge-danger"><?php echo $lowStockCount;?> </span>
                            <?php } ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/top_selling_products.php" class="nav-link text-white">
                        <i class="fas fa-shop"></i> <span>Productos Más Vendidos</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/inventory_status_report.php" class="nav-link text-white">
                        <i class="fas fa-warehouse"></i> <span>Estado del Inventario</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/sales_analysis.php" class="nav-link text-white">
                        <i class="fas fa-chart-line"></i> <span>Análisis de Ventas</span>
                    </a>
                </li>
            </ul>
</div>