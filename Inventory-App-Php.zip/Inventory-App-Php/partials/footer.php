<?php
// Footer (Archivo: views/partials/footer.php)
echo '<footer class="footer mt-5 py-3 bg-dark text-white">
        <div class="container text-center" >
            <span>&copy; ' . date('Y') . ' Inventario-App. Todos los derechos reservados. Ps Rios</span>
        </div>
      </footer>'
?>
