
//Hacer que el mensaje success desaparezca después de unos segundos
setTimeout(function() {
    const alert = document.querySelector('.alert-success');
    if (alert) {
        alert.style.display = 'none';
    }
}, 5000); // 5000 ms = 5 segundos