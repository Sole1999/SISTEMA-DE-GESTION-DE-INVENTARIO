<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Asegúrate de que el usuario esté autenticado y de que haya una sesión activa

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username']; // Almacenar el nombre de usuario desde la sesión
} else {
    // Si no hay un nombre de usuario, podrías redirigir al login o establecer un valor por defecto
    $username = "Invitado";
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .profile-icon {
            position: fixed;
            top: 15px;
            right: 15px;
            cursor: pointer;
        }

        .profile-menu {
            position: absolute;
            top: 60px;
            right: 15px;
            width: 250px;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            z-index: 100;
            display: none;
        }

        .profile-menu .menu-item {
            padding: 8px 0;
            border-bottom: 1px solid #ddd;
        }

        .profile-menu .menu-item:last-child {
            border-bottom: none;
        }

        .profile-menu a {
            color: #007bff;
            text-decoration: none;
        }

        .profile-menu a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <!-- Ícono del perfil -->
    <div class="profile-icon">
        <img src="../images/img1.png" alt="Perfil" id="profileIcon" class="rounded-circle" width="50" height="50">
    </div>
    <!-- Menú de perfil flotante -->
    <div id="profileMenu" class="profile-menu">
        <div class="menu-item">
            <strong><?php echo htmlspecialchars($username); ?></strong>
        </div>
        <div class="menu-item">
            <a href="../views/update_profile.php"  onclick="openProfileUpdate()">Ajustes</a>
        </div>
        <div class="menu-item">
            <a href="../actions/logout.php">Cerrar sesión</a>
        </div>
    </div>




    <script>
        // JavaScript para alternar la visibilidad del menú de perfil
        const profileIcon = document.getElementById('profileIcon');
        const profileMenu = document.getElementById('profileMenu');

        profileIcon.addEventListener('click', () => {
            profileMenu.style.display = profileMenu.style.display === 'none' || profileMenu.style.display === '' ? 'block' : 'none';
        });

        // Cierra el menú si se hace clic fuera del área del menú
        document.addEventListener('click', (event) => {
            if (!profileMenu.contains(event.target) && !profileIcon.contains(event.target)) {
                profileMenu.style.display = 'none';
            }
        });

        function openProfileUpdate() {
            // Aquí podrías agregar el código para abrir el formulario de actualización de perfil
            //alert('Funcionalidad para editar el perfil');
        }
    </script>
</body>

</html>
