<?php
// 4.2 Clase Venta (Archivo: models/Sale.php)
namespace Models;

use Database\Database;
use \PDO;

$database = new Database();
$db = $database->getConnection();

if ($db === null) {
    die("No se pudo conectar a la base de datos. Verifica la configuración.");
}

$sale = new Sale($db);


class Sale
{
    private $conn;
    private $table_name = "sales";

    public $id;
    public $product_id;
    public $quantity;
    public $total_price;
    public $sale_date;

    // Constructor
    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Crear una nueva venta
    public function create()
    {
        $query = "INSERT INTO " . $this->table_name . " (product_id, quantity, total_price, sale_date) VALUES (:product_id, :quantity, :total_price, :sale_date)";
        
        $stmt = $this->conn->prepare($query);

        // Enlace de parámetros
        $stmt->bindParam(':product_id', $this->product_id);
        $stmt->bindParam(':quantity', $this->quantity);
        $stmt->bindParam(':total_price', $this->total_price);
        $stmt->bindParam(':sale_date', $this->sale_date);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Obtener los productos más vendidos
    public function getTopSellingProducts()
    {
        $query = "SELECT p.name AS product_name, SUM(s.quantity) AS total_sales FROM " . $this->table_name . " s INNER JOIN products p ON s.product_id = p.id GROUP BY p.name ORDER BY total_sales DESC LIMIT 10";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener los periodos de mayor venta
    public function getPeakSalesPeriods()
    {
        $query = "SELECT DATE(sale_date) AS sale_date, SUM(total_price) AS total_sales FROM " . $this->table_name . " GROUP BY sale_date ORDER BY total_sales DESC LIMIT 10";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener tendencias estacionales
    public function getSeasonalTrends()
    {
        $query = "SELECT MONTH(sale_date) AS season, COUNT(*) AS value FROM " . $this->table_name . " GROUP BY season ORDER BY season";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    /*
    // Crear una nueva venta
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " (product_id, quantity, total_price) VALUES (:product_id, :quantity, :total_price)";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":product_id", $this->product_id);
        $stmt->bindParam(":quantity", $this->quantity);
        $stmt->bindParam(":total_price", $this->total_price);

        if ($stmt->execute()) {
            // Actualizar inventario del producto vendido
            $this->updateProductInventory($this->product_id, $this->quantity);
            return true;
        }
        return false;
    }*/

    // Método para actualizar el inventario del producto después de una venta
    private function updateProductInventory($product_id, $quantity) {
        $query = "UPDATE products SET quantity = quantity - :quantity WHERE id = :product_id";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":quantity", $quantity);
        $stmt->bindParam(":product_id", $product_id);
        
        $stmt->execute();
    }

    // Leer todas las ventas
    public function readAll() {
        $query = "SELECT s.*, p.name as product_name FROM " . $this->table_name . " s LEFT JOIN products p ON s.product_id = p.id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Leer una venta por ID
    public function readOne() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $this->product_id = $row['product_id'];
            $this->quantity = $row['quantity'];
            $this->total_price = $row['total_price'];
        }
    }

    // Actualizar una venta
    public function update() {
        $query = "UPDATE " . $this->table_name . " SET product_id = :product_id, quantity = :quantity, total_price = :total_price WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":product_id", $this->product_id);
        $stmt->bindParam(":quantity", $this->quantity);
        $stmt->bindParam(":total_price", $this->total_price);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Eliminar una venta
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Obtener productos más vendidos con la categoría
    
    public function getTopSelling() {
        $query = "SELECT p.name AS product_name, c.name AS category_name, SUM(s.quantity) AS total_sold
                FROM sales s
                LEFT JOIN products p ON s.product_id = p.id
                LEFT JOIN categories c ON p.category_id = c.id
                GROUP BY s.product_id
                ORDER BY total_sold DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Obtener el total de las ventas
    public function getTotalSales() {
        $query = "SELECT SUM(total_price) AS total_sales FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total_sales'] ?? 0;
    }

    
}

?>