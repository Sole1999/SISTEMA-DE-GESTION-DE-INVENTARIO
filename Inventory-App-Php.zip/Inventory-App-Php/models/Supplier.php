<?php

// 4.3 Clase Proveedor (Archivo: models/Supplier.php)
namespace Models;

use Database\Database;
use \PDO;
use PDOException;

class Supplier {
    private $conn;
    private $table_name = "suppliers";

    public $id;
    public $name;
    public $contact_info;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Crear un nuevo proveedor
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " (name, contact_info) VALUES (:name, :contact_info)";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":contact_info", $this->contact_info);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Leer todos los proveedores
    public function readAll() {
        $query = "SELECT * FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Leer un proveedor por ID
    public function readOne() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $this->name = $row['name'];
            $this->contact_info = $row['contact_info'];
        }
    }

    // Actualizar un proveedor
    public function update() {
        $query = "UPDATE " . $this->table_name . " SET name = :name, contact_info = :contact_info WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":contact_info", $this->contact_info);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Eliminar un proveedor
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }


    // Obtener la lista de proveedores activos
    public function getActiveSuppliers() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE status = 'activo'";
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Puedes agregar un log o manejar el error de la forma que consideres
            return [];
        }
    }


}


?>