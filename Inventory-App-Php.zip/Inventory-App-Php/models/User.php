<?php
// Archivo User.php
namespace Models;

use PDO;

class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $username;
    public $email;
    public $password;

    

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create(): bool {
        $query = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
    
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':password', $this->password);
    
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
    

    public function readByUsername() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE username = :username LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $this->username);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    

    public function update() {
        $query = "UPDATE users SET username = :username, email = :email WHERE id = :id";
        $stmt = $this->conn->prepare($query);
    
        // Enlace de parámetros
        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':id', $this->id);
    
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }


    public function readById() {
        $query = "SELECT * FROM users WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
    
        // Enlazar el parámetro ID
        $stmt->bindParam(':id', $this->id);
    
        // Ejecutar la consulta
        $stmt->execute();
    
        // Obtener el resultado
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
        // Asignar los valores a las propiedades del objeto
        if ($row) {
            $this->username = $row['username'];
            $this->email = $row['email'];
        }
    }

    
}
?>