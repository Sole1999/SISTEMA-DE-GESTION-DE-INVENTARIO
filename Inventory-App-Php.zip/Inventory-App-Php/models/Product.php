<?php
/// 4. Clase Producto (Archivo: models/Product.php)
namespace Models;

use Database\Database;
use \PDO;

class Product {
    private $conn;
    private $table_name = "products";

    public $id;
    public $name;
    public $quantity;
    public $price;
    public $category_id;
    public $created_at;
    public $category_name; // Nueva propiedad para almacenar el nombre de la categoría

    public function __construct($db) {
        $this->conn = $db;
    }

    // Crear un nuevo producto
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " (name, quantity, price, category_id) VALUES (:name, :quantity, :price, :category_id)";
        $stmt = $this->conn->prepare($query);
        
        // Vincular parámetros
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":quantity", $this->quantity);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":category_id", $this->category_id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Leer todos los productos
    public function readAll() {
        $query = "SELECT p.*, c.name as category_name FROM " . $this->table_name . " p LEFT JOIN categories c ON p.category_id = c.id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Leer un solo producto por ID
    public function readOne() {
        $query = "SELECT p.*, c.name as category_name FROM " . $this->table_name . " p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = :id LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $this->name = $row['name'];
            $this->quantity = $row['quantity'];
            $this->price = $row['price'];
            $this->category_id = $row['category_id'];
            $this->category_name = $row['category_name'];
        }
    }

    // Actualizar un producto
    public function update() {
        $query = "UPDATE " . $this->table_name . " SET name = :name, quantity = :quantity, price = :price, category_id = :category_id WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":quantity", $this->quantity);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":category_id", $this->category_id);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Eliminar un producto
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Obtener productos agotados con la categoría
    public function getOutOfStock() {
        $query = "SELECT p.*, c.name as category_name FROM " . $this->table_name . " p LEFT JOIN categories c ON p.category_id = c.id WHERE p.quantity = 0";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Obtener el estado del inventario
    public function getInventoryStatus() {
        $query = "SELECT p.*, c.name as category_name FROM " . $this->table_name . " p LEFT JOIN categories c ON p.category_id = c.id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Obtener productos con bajo stock
    public function getLowStockProducts($threshold = 10) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE quantity < :threshold";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":threshold", $threshold, PDO::PARAM_INT);
        $stmt->execute();

        // Devolver el resultado como un array
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener el valor total del inventario
    public function getTotalInventoryValue() {
        $query = "SELECT SUM(quantity * price) AS total_inventory_value FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total_inventory_value'] ?? 0;
    }

}

?>