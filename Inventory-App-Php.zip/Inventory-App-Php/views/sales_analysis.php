<?php
// Archivo: sales_analysis.php

include_once "../database/Database.php";
include_once "../models/Sale.php";
include_once "../models/Product.php";
include_once "../models/Category.php";

use Database\Database;
use Models\Sale;
use Models\Product;
use Models\Category;

$database = new Database();
$db = $database->getConnection();

$sale = new Sale($db);
$product = new Product($db);
$category = new Category($db);

// Obtener los productos más vendidos
$topSellingProducts = $sale->getTopSellingProducts();

// Obtener los periodos de mayor venta
$peakSalesPeriods = $sale->getPeakSalesPeriods();

// Obtener tendencias estacionales
$seasonalTrends = $sale->getSeasonalTrends();
?>

<?php include_once "../partials/header.php"; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Ventas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include_once "../partials/menu.php"; ?>

    <div id="content" class="container-fluid">
        <div class="container mt-1 ml-1">
            <h2 class="mb-4">Análisis de Ventas</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            Productos Más Vendidos
                        </div>
                        <div class="card-body">
                            <canvas id="topSellingChart"></canvas>
                            <ul class="mt-3">
                                <?php if (!empty($topSellingProducts)) {
                                    foreach ($topSellingProducts as $product) { ?>
                                        <li><?php echo htmlspecialchars($product['product_name']); ?> (<?php echo $product['total_sales']; ?> ventas)</li>
                                <?php }
                                } else { ?>
                                    <li>No hay datos disponibles.</li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            Periodos de Mayor Venta
                        </div>
                        <div class="card-body">
                            <canvas id="peakSalesChart"></canvas>
                            <ul class="mt-3">
                                <?php if (!empty($peakSalesPeriods)) {
                                    foreach ($peakSalesPeriods as $period) { ?>
                                        <li><?php echo htmlspecialchars($period['sale_date']); ?> (<?php echo $period['total_sales']; ?> ventas)</li>
                                <?php }
                                } else { ?>
                                    <li>No hay datos disponibles.</li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        Tendencias Estacionales
                    </div>
                    <div class="card-body">
                        <canvas id="seasonalTrendsChart"></canvas>
                        <ul class="mt-3">
                            <?php if (!empty($seasonalTrends)) {
                                foreach ($seasonalTrends as $trend) {
                                    // Verificar si la clave 'description' existe en el array $trend
                                    if (isset($trend['description'])) {
                                        $description = $trend['description'];
                                    } else {
                                        $description = "No description available";
                                    }
                                    ?>
                                    <li><?php echo htmlspecialchars($trend['season']); ?>: <?php echo htmlspecialchars($description); ?></li>
                            <?php }
                            } else { ?>
                                <li>No hay datos disponibles.</li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Código para renderizar los gráficos utilizando Chart.js
    const ctxTopSelling = document.getElementById('topSellingChart').getContext('2d');
    new Chart(ctxTopSelling, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_column($topSellingProducts, 'product_name')); ?>,
            datasets: [{
                label: 'Ventas',
                data: <?php echo json_encode(array_column($topSellingProducts, 'total_sales')); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    const ctxPeakSales = document.getElementById('peakSalesChart').getContext('2d');
    new Chart(ctxPeakSales, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($peakSalesPeriods, 'sale_date')); ?>,
            datasets: [{
                label: 'Ventas',
                data: <?php echo json_encode(array_column($peakSalesPeriods, 'total_sales')); ?>,
                backgroundColor: 'rgba(255, 99, 132, 0.6)',
                borderColor: 'rgba(255, 99, 132, 1)',
                fill: false
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    const ctxSeasonalTrends = document.getElementById('seasonalTrendsChart').getContext('2d');
    new Chart(ctxSeasonalTrends, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode(array_column($seasonalTrends, 'season')); ?>,
            datasets: [{
                data: <?php echo json_encode(array_column($seasonalTrends, 'value')); ?>,
                backgroundColor: [
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                    'rgba(255, 205, 86, 0.6)',
                    'rgba(201, 203, 207, 0.6)'
                ],
                borderColor: 'rgba(255, 255, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true
        }
    });
</script>
</html>
