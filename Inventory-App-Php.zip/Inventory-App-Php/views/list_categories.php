<?php
include_once "../database/Database.php";
include_once "../models/Category.php";

use Database\Database;
use Models\Category;

$database = new Database();
$db = $database->getConnection();
$category = new Category($db);
$stmt = $category->readAll();

if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo "<div class='alert alert-success text-center '>Categoría creada correctamente.</div>";
}

?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Categorías</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>

<?php include_once "../partials/menu.php"; ?>

<div id="content" class="container-fluid">

    <div class="container mt-1 ml-1">
        <h2>Lista de Categorías</h2>
        <a href="../actions/add_category.php" class="btn btn-primary mb-3">Agregar Categoría</a>
        <div class="card mt-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" style="max-width: 1000px;">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td>
                                        <a href="../actions/update_category.php?id=<?php echo $row['id']; ?>" class="btn btn-warning">Editar</a>
                                        <a href="../actions/delete_category.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Eliminar</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../partials/functions.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
