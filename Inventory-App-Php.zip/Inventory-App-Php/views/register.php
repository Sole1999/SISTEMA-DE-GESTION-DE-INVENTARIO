<?php
include_once "../database/Database.php";
include_once "../models/User.php";

use Database\Database;
use Models\User;

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Manejar el registro del usuario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user->username = htmlspecialchars(strip_tags($_POST['username']));
    $user->email = htmlspecialchars(strip_tags($_POST['email']));
    $user->password = password_hash(htmlspecialchars(strip_tags($_POST['password'])), PASSWORD_BCRYPT);

    if ($user->create()) {
        echo "<script>alert('Usuario registrado correctamente.'); window.location.href = '../views/login.php';</script>";
    } else {
        echo "<script>alert('No se pudo registrar el usuario.');</script>";
    }
}
?>

<?php include_once "../partials/sidebar.php"; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h2 class="mb-4">Registrar Usuario</h2>
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="username">Nombre de Usuario</label>
                        <input type="text" name="username" id="username" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Correo Electrónico</label>
                        <input type="email" name="email" id="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Registrar</button>
                    <a href="../views/login.php" class="btn btn-secondary">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</html>
