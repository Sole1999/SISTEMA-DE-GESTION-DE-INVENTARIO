<?php
// Archivo: dashboard.php

namespace Views;

use Database\Database;
use Models\Sale;
use Models\Product;
use Models\Supplier;
use PDO;

include_once '../database/Database.php';
include_once '../models/Sale.php';
include_once '../models/Product.php';
include_once '../models/Supplier.php';

$database = new Database();
$db = $database->getConnection();

$sale = new Sale($db);
$product = new Product($db);
$supplier = new Supplier($db);

// Obtener datos clave para el dashboard
$totalSales = $sale->getTotalSales();
$lowStockProducts = $product->getLowStockProducts(10); // Umbral definido para productos con bajo stock
$totalInventoryValue = $product->getTotalInventoryValue();
$activeSuppliers = $supplier->getActiveSuppliers();
$topSellingProducts = $sale->getTopSellingProducts();

// Obtener productos con bajo stock
$lowStockProducts = $product->getLowStockProducts(threshold: 10); // Umbral definido para productos con bajo stock

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Resumido</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="menu-open movable-card">
    <?php include_once '../partials/menu.php'; ?>

    <div id="content" class="container-fluid">
        <div id="content" class="container mt-1 ml-1">

            <div class="container-fluid  text-center">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card text-white bg-primary mb-3">
                            <div class="card-header">
                            <font FACE="impact" SIZE=5 COLOR="teal">Total Ventas</font>
                            </div>
                            <div class="card-body">
                                <h3 class="card-title"><font FACE="arial"  COLOR="green"><b>$<?php echo number_format($totalSales, 2); ?></b></font></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-success mb-3">
                            <div class="card-header">
                            <font FACE="impact" SIZE=5 COLOR="teal">Valor Total de Inventario</font>
                            </div>
                            <div class="card-body">
                                <h3 class="card-title">
                                    <font FACE="arial"  COLOR="green"><b>$<?php echo number_format($totalInventoryValue, 2); ?></b></font></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-warning mb-3">
                            <div class="card-header">
                            <font FACE="impact" SIZE=5 COLOR="teal">Proveedores Activos</font>
                            </div>
                            <div class="card-body">
                                <h3 class="card-title text-center">
                                    <font FACE="arial" COLOR="black"><b><?php echo count($activeSuppliers); ?></b></font></h3>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-md-9">
                        <div class="card mt-1 ml-1 mb-5">
                            <div class="card-body text-center">
                                <div class="card-header ml-1">
                                <font FACE="impact" SIZE=5 COLOR="teal">Productos Más Vendidos</font>
                                </div>
                                <div class="card-body">
                                    <canvas id="topSellingProductsChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-header" >
                            <font FACE="impact" SIZE=5 COLOR="teal">Productos con Bajo Stock</font>
                            </div>
                            <div class="card-body">
                                <ul>
                                    <?php if (!empty($lowStockProducts)) {
                                        foreach ($lowStockProducts as $product) { ?>
                                            <li><font FACE="arial" COLOR="black"><b><?php echo htmlspecialchars($product['name']); ?> - Cantidad: <?php echo htmlspecialchars($product['quantity']); ?></b></font></li>
                                    <?php }
                                    } else { ?>
                                        <li>No hay productos con bajo stock.</li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                // Gráfico de Productos Más Vendidos
                const ctxTopSelling = document.getElementById('topSellingProductsChart').getContext('2d');
                new Chart(ctxTopSelling, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode(array_column($topSellingProducts, 'product_name')); ?>,
                        datasets: [{
                            label: 'Ventas',
                            data: <?php echo json_encode(array_column($topSellingProducts, 'total_sales')); ?>,
                            backgroundColor: 'red',
                            borderColor: 'black',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            </script>
        </div>
    </div>    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
