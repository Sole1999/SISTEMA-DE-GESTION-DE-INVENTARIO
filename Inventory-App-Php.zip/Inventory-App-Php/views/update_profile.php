<?php
// update_profile.php - Configuración para actualizar datos de perfil

include_once "../database/Database.php";
include_once "../models/User.php";

use Database\Database;
use Models\User;

// Iniciar la sesión para obtener el ID del usuario actual
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../views/login.php");
    exit;
}

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

// Obtener el usuario actual por ID
$user->id = $_SESSION['user_id'];
$user->readById(); // Obtener los datos actuales del usuario para mostrarlos en el formulario

// Manejar la actualización del perfil del usuario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user->username = htmlspecialchars(strip_tags($_POST['username']));
    $user->email = htmlspecialchars(strip_tags($_POST['email']));

    if ($user->update()) {
        $_SESSION['username'] = $user->username; // Actualizar el nombre de usuario en la sesión
        $success_message = "Datos actualizados correctamente.";
    } else {
        $error_message = "Hubo un problema al actualizar los datos.";
    }
}
?>

<?php include_once "../partials/header.php"; ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Perfil</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>

<body>
    <?php include_once "../partials/menu_actions.php"; ?>

    <div id="content" class="container mt-5">
        <h2 class="mb-4">Actualizar Perfil</h2>
        <?php
        if (isset($success_message)) {
            echo "<div class='alert alert-success'>$success_message</div>";
        }
        if (isset($error_message)) {
            echo "<div class='alert alert-danger'>$error_message</div>";
        }
        ?>
        <div class="card">
            <div class="card-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="username">Nombre de Usuario</label>
                        <input type="text" name="username" id="username" class="form-control" value="<?php echo htmlspecialchars($user->username); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Correo Electrónico</label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($user->email); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Actualizar Perfil</button>
                    <a href="../views/principal.php" class="btn btn-secondary">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
