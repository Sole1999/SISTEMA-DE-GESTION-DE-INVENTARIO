<?php
include_once '../database/Database.php';
include_once '../models/User.php';
include_once '../vendor/autoload.php';

use Database\Database;
use Models\User;

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Manejar la actualización de usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $username = htmlspecialchars(strip_tags($_POST['username']));
    $email = htmlspecialchars(strip_tags($_POST['email']));
    $user->$username;
    $user->$email;

    if ($user->update()) {
        $success_message = "Datos actualizados correctamente.";
    } else {
        $error_message = "Hubo un problema al actualizar los datos.";
    }
}

// Manejar el cierre de sesión
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['logout'])) {
    // Código para cerrar sesión aquí
    echo "<script>alert('Sesión cerrada correctamente.'); window.location.href = 'login.php';</script>";
}

?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>

<body>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
        <div class="card p-4" style="width: 20rem;">
            <h3 class="text-center mb-4">Mi Perfil</h3>
            <?php if (isset($error_message)) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error_message; ?>
                </div>
            <?php } ?>
            <?php if (isset($success_message)) { ?>
                <div class="alert alert-success" role="alert">
                    <?php echo $success_message; ?>
                </div>
            <?php } ?>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="username">Nombre de Usuario</label>
                    <input type="text" name="username" id="username" class="form-control" value="<?php echo htmlspecialchars($user->username); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Correo Electrónico</label>
                    <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($user->email); ?>" required>
                </div>
                <button type="submit" name="update" class="btn btn-primary btn-block">Actualizar Datos</button>
            </form>
            <form action="" method="POST" class="mt-3">
                <button type="submit" name="logout" class="btn btn-danger btn-block">Cerrar Sesión</button>
            </form>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</html>
