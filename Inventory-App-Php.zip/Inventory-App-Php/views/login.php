<?php
session_start();
include_once '../database/Database.php';
include_once '../models/User.php';
include_once '../vendor/autoload.php';

use Database\Database;
use Models\User;

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Manejar el inicio de sesión
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars(strip_tags($_POST['username']));
    $password = htmlspecialchars(strip_tags($_POST['password']));

    // Verificar usuario y contraseña
    $user->username = $username;
    $userData = $user->readByUsername();

    if ($userData && password_verify($password, $userData['password'])) {
        // Establecer sesión y racha de inicio de sesión
        $_SESSION['user_id'] = $userData['id'];
        $_SESSION['username'] = $userData['username'];
        $_SESSION['login_streak'] = isset($_SESSION['login_streak']) ? $_SESSION['login_streak'] + 1 : 1;
        header("Location: principal.php");
        exit;
    } else {
        $error_message = "Nombre de usuario o contraseña incorrectos.";
    }
}
?>

<?php include_once "../partials/sidebar.php"; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>

<body>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
        <div class="card p-4" style="width: 25rem;">
            <h3 class="text-center mb-4">Iniciar Sesión</h3>
            <?php if (isset($error_message)) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error_message; ?>
                </div>
            <?php } ?>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="username">Nombre de Usuario</label>
                    <input type="text" name="username" id="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Iniciar Sesión</button>
            </form>
            <div class="text-center mt-3">
                <a href="register.php">Registrarse</a>
            </div>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</html>