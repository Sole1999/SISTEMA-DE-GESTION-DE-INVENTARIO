<?php 

include_once "../database/Database.php";
include_once "../models/Product.php";
include_once "../partials/header.php";

use Database\Database;
use Models\Product;

$database = new Database();
$db = $database->getConnection();

$product = new Product($db);

// Definir el umbral de alerta
$lowStockThreshold = 5;

// Obtener productos con bajo stock
$lowStockProducts = $product->getLowStockProducts($lowStockThreshold);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Inventarios</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include_once "../partials/menu.php"; ?>

    <div id="content" class="container-fluid">
        <div id="content" class="container mt-1 ml-3 py-3">
            <!-- Mostrar alertas de bajo stock -->
            <?php if (count($lowStockProducts) > 0) { ?>
                <div class="alert alert-warning">
                    <strong>¡Advertencia!</strong> Los siguientes productos tienen cantidades por debajo del nivel permitido:
                        <ul>
            <?php foreach ($lowStockProducts as $row) { ?>
                                <li><?php echo htmlspecialchars($row['name']) . " - Cantidad: " . htmlspecialchars($row['quantity']); ?></li>
                            <?php } ?>
                        </ul>
                </div>
            <?php } ?>
            <div class="card mt-1 ml-1">
                <div class="card-body text-center">
                    <h2>Bienvenido al Sistema de Gestión de Inventario</h2>
                    <FOnt FACE="impact" COLOR="blue"><h1>Inventory-App</h1></FOnt>
                </div>
            </div>
            <?php include_once "dashboard.php"; ?>
        </div>
    </div>   
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</html>
