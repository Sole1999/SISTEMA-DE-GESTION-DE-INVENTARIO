<?php
// 7. Listar Productos (Archivo: views/list_products.php)
include_once "../database/Database.php";
include_once "../models/Product.php";

use Database\Database;
use Models\Product;

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);
$stmt = $product->readAll();

if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo "<div class='alert alert-success text-center '>Producto creado correctamente.</div>";
}
?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include_once "../partials/menu.php"; ?>

    
    <div id="content" class="container-fluid">

        <div id="content" class="container mt-1 ml-1">
            <h2 class="mb-4">Lista de Productos</h2>
            <a href="../actions/add_product.php" class="btn btn-primary mb-3">Agregar Producto</a>
            <div class="card mt-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Nombre</th>
                                        <th>Categoría</th>
                                        <th>Cantidad</th>
                                        <th>Precio</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                            <td><?php echo htmlspecialchars($row['price']); ?></td>
                                            <td>
                                                <a href="../actions/update_product.php?id=<?php echo htmlspecialchars($row['id']); ?>" class="btn btn-sm btn-warning">Editar</a>
                                                <a href="../actions/delete_product.php?id=<?php echo htmlspecialchars($row['id']); ?>" onclick="return confirm('¿Está seguro de que desea eliminar este producto?');" class="btn btn-sm btn-danger">Eliminar</a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../partials/functions.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
