<?php
include_once "../database/Database.php";
include_once "../models/Sale.php";

use Database\Database;
use Models\Sale;

$database = new Database();
$db = $database->getConnection();
$sale = new Sale($db);
$stmt = $sale->getTopSelling();
?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Productos Más Vendidos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include_once "../partials/menu.php"; ?>
    

    <div id="content" class="container-fluid">
        <div id="content" class="container mt-1 ml-1">
            <h2 class="mt-4">Reporte de Productos Más Vendidos</h2>
            <button onclick="window.location.href='../reports/generate_top_selling_report_csv.php'" class="btn btn-success mb-3">Generar CSV</button>
            <button onclick="window.location.href='../reports/generate_top_selling_report_pdf.php'" class="btn btn-danger mb-3">Generar PDF</button>
            <div class="card mt-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Nombre del Producto</th>
                                    <th>Cantidad Vendida</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['total_sold']); ?></td>
                                        <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<br>
<br>
<br>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</html>
