<?php

?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">

    
</head>
<body id="content-pr">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Inventory-App</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href=""></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href=""></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="views/login.php">Iniciar sesión</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="views/register.php">Registrarse</a>
            </li>
        </ul>
    </div>
</nav>

    <div id="content" class="container-fluid">
        <div id="content" class="container mt-5 ml-100 py-3">
            <div class="card-pr">
                <div class="card col-md-5">
                    <div class="card-block text-center">
                        
                        <h2 class="mt-4">Sistema de Gestión de Inventario</h2>
                        <FOnt FACE="impact" COLOR="blue"><h1>Inventory-App</h1></FOnt>
                        <br>
                        <h4>Todo a tu alcance.</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<?php include_once "partials/footer.php"; ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</html>