<?php
include_once "database/Database.php";
include_once "models/Product.php";
include_once "models/Sale.php";

use Database\Database;
use Models\Product;
use Models\Sale;

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);
$sale = new Sale($db);

// Generar Reporte de Productos Agotados
function generateOutOfStockReportCSV($product) {
    $stmt = $product->getOutOfStock();
    $filename = "reports/out_of_stock_report_" . date('Ymd_His') . ".csv";

    $file = fopen($filename, 'w');
    fputcsv($file, ['ID', 'Nombre', 'Cantidad']);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($file, [$row['id'], $row['name'], $row['quantity']]);
    }
    fclose($file);
}

// Generar Reporte de Productos Más Vendidos
function generateTopSellingReportCSV($sale) {
    $stmt = $sale->getTopSelling();
    $filename = "reports/top_selling_report_" . date('Ymd_His') . ".csv";

    $file = fopen($filename, 'w');
    fputcsv($file, ['Nombre del Producto', 'Cantidad Vendida']);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($file, [$row['product_name'], $row['total_sold']]);
    }
    fclose($file);
}

// Generar Reporte del Estado General del Inventario
function generateInventoryStatusReportCSV($product) {
    $stmt = $product->getInventoryStatus();
    $filename = "reports/inventory_status_report_" . date('Ymd_His') . ".csv";

    $file = fopen($filename, 'w');
    fputcsv($file, ['Nombre', 'Cantidad', 'Precio', 'Categoría']);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($file, [$row['name'], $row['quantity'], $row['price'], $row['category_name']]);
    }
    fclose($file);
}

// Llamar a las funciones para generar los reportes
generateOutOfStockReportCSV($product);
generateTopSellingReportCSV($sale);
generateInventoryStatusReportCSV($product);

echo "Reportes generados correctamente.\n";


/* cd C:\xampp\htdocs\Inventory-App-PHP
C:\xampp\php\php.exe generate_reports.php */ // Ejecutar esto (archivo) desde CMD

?>



