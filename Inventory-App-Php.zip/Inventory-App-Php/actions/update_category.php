<?php
//Actualizar Categoría
include_once '../database/Database.php';
include_once '../models/Category.php';

use Database\Database;
use Models\Category;

$database = new Database();
$db = $database->getConnection();
$category = new Category($db);

// Obtener la categoría por ID para cargar los datos en el formulario
if (isset($_GET['id'])) {
    $category->id = $_GET['id'];
    $category->readOne();
}

// Manejar la actualización de la categoría
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category->id = $_POST['id'];
    $category->name = htmlspecialchars(strip_tags($_POST['name']));

    if ($category->update()) {
        echo "<script>alert('Categoría actualizada correctamente.'); window.location.href = '../views/list_categories.php';</script>";
    } else {
        echo "<script>alert('No se pudo actualizar la categoría.');</script>";
    }
}
?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Categoría</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>

<body>
    <?php include_once "../partials/menu_actions.php"; ?>

    <div id="content" class="container-fluid">
        <div id="content" class="container mt-1 ml-1">
            <h2 class="mb-4">Editar Categoría</h2>
            <div class="card mt-3">
                <div class="card-body">
                    <form action="" method="POST">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($category->id); ?>">
                        <div class="form-group">
                            <label for="name">Nombre de la Categoría</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars( $category->name); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Actualizar Categoría</button>
                        <a href="../views/list_categories.php" class="btn btn-secondary">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<?php include_once "../partials/footer.php"; ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</html>
