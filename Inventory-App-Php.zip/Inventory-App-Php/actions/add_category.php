<?php
include_once "../database/Database.php";
include_once "../models/Category.php";

use Database\Database;
use Models\Category;

if ($_POST) {
    $database = new Database();
    $db = $database->getConnection();
    $category = new Category($db);

    $category->name = $_POST['name'];

    $categoryAddedSuccessfully = $category->create();

    if ($categoryAddedSuccessfully) {
        header("Location: ../views/list_categories.php?success=1");
        exit();
    } else {
        echo "<p>Error al agregar la categoría</p>";
    }
}
?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Categoría</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>

<?php include_once "../partials/menu_actions.php"; ?>

<div id="content" class="container-fluid">

    <div class="container mt-1 ml-1">
        <h2 class="mb-4">Agregar Categoría</h2>
        <div class="card mt-4">
            <div class="card-body">
                <form action="add_category.php" method="POST">
                    <div class="form-group">
                        <label for="name">Nombre de la Categoría</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-success mt-3">Agregar</button>
                    <a href="../views/list_categories.php" class="btn btn-secondary mt-3">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include_once "../partials/footer.php"; ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>
