<?php
// 8. Actualizar Producto (Archivo: views/update_product.php)

include_once "../database/Database.php";
include_once "../models/Product.php";
include_once "../models/Category.php";

use Database\Database;
use Models\Product;
use Models\Category;

$database = new Database();
$db = $database->getConnection();

$product = new Product($db);
$category = new Category($db);

// Obtener el producto por ID para cargar los datos en el formulario
if (isset($_GET['id'])) {
    $product->id = $_GET['id'];
    $product->readOne();
}

// Manejar la actualización del producto
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product->id = $_POST['id'];
    $product->name = htmlspecialchars(strip_tags($_POST['name']));
    $product->quantity = htmlspecialchars(strip_tags($_POST['quantity']));
    $product->price = htmlspecialchars(strip_tags($_POST['price']));
    $product->category_id = htmlspecialchars(strip_tags($_POST['category_id']));

    if ($product->update()) {
        echo "<script>alert('Producto actualizado correctamente.'); window.location.href = '../views/list_products.php';</script>";
    } else {
        echo "<script>alert('No se pudo actualizar el producto.');</script>";
    }
}

// Obtener todas las categorías para el dropdown
$categories = $category->readAll();
?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>

<body>
    <?php include_once "../partials/menu_actions.php"; ?>

    <div id="content" class="container-fluid">
        <div id="content" class="container mt-1 ml-1">
            <h2 class="mb-4">Editar Producto</h2>
            <div class="card mt-3">
                <div class="card-body">
                    <form action="" method="POST">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($product->id); ?>">
                        <div class="form-group">
                            <label for="name">Nombre del Producto</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($product->name); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="quantity">Cantidad</label>
                            <input type="number" name="quantity" id="quantity" class="form-control" value="<?php echo htmlspecialchars($product->quantity); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="price">Precio</label>
                            <input type="number" step="0.01" name="price" id="price" class="form-control" value="<?php echo htmlspecialchars($product->price); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Categoría</label>
                            <select name="category_id" id="category_id" class="form-control" required>
                                <option value="">Seleccione una categoría</option>
                                <?php while ($row = $categories->fetch(PDO::FETCH_ASSOC)) { ?>
                                    <option value="<?php echo $row['id']; ?>" <?php if ($row['id'] == $product->category_id) echo 'selected'; ?>>
                                        <?php echo htmlspecialchars($row['name']); ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Actualizar Producto</button>
                        <a href="../views/list_products.php" class="btn btn-secondary">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<br>
<br>
<br>
<?php include_once "../partials/footer.php"; ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</html>
