<?php
// Eliminar y Actualizar Proveedor
include_once '../database/Database.php';
include_once '../models/Supplier.php';

use Database\Database;
use Models\Supplier;

$database = new Database();
$db = $database->getConnection();
$supplier = new Supplier($db);

// Obtener el proveedor por ID para cargar los datos en el formulario
if (isset($_GET['id'])) {
    $supplier->id = $_GET['id'];
    $supplier->readOne();
}

// Manejar la actualización del proveedor
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $supplier->id = $_POST['id'];
    $supplier->name = htmlspecialchars(strip_tags($_POST['name']));
    $supplier->contact_info = htmlspecialchars(strip_tags($_POST['contact_info']));

    if ($supplier->update()) {
        echo "<script>alert('Proveedor actualizado correctamente.'); window.location.href = '../views/list_suppliers.php';</script>";
    } else {
        echo "<script>alert('No se pudo actualizar el proveedor.');</script>";
    }
}
?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Proveedor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>

<body>
    <?php include_once "../partials/menu_actions.php"; ?>

    <div id="content" class="container-fluid">
        <div id="content" class="container mt-1 ml-1">
            <h2 class="mb-4">Editar Proveedor</h2>
            <div class="card mt-3">
                <div class="card-body">
                    <form action="" method="POST">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($supplier->id); ?>">
                        <div class="form-group">
                            <label for="name">Nombre del Proveedor</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($supplier->name); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="contact_info">Información de Contacto</label>
                            <textarea name="contact_info" id="contact_info" class="form-control" required><?php echo htmlspecialchars($supplier->contact_info); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Actualizar Proveedor</button>
                        <a href="../views/list_suppliers.php" class="btn btn-secondary">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

<?php include_once "../partials/footer.php"; ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</html>
