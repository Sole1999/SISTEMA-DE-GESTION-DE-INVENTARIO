<?php
// Eliminar Categoría
include_once '../database/Database.php';
include_once '../models/Category.php';

use Database\Database;
use Models\Category;

$database = new Database();
$db = $database->getConnection();
$category = new Category($db);

if (isset($_GET['id'])) {
    $category->id = htmlspecialchars(strip_tags($_GET['id']));

    if ($category->delete()) {
        echo "<script>
                alert('Categoría eliminada correctamente.');
                window.location.href = '../views/list_categories.php';
              </script>";
    } else {
        echo "<script>
                alert('No se pudo eliminar la categoría.');
                window.location.href = '../views/list_categories.php';
              </script>";
    }
} else {
    // Si no hay 'id', redirigir al usuario a la página principal
    echo "<script>window.location.href = '../index.php';</script>";
}

?>