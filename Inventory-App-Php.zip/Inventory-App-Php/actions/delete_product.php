<?php
// 9. Eliminar Producto (Archivo: views/delete_product.php)
include_once '../database/Database.php';
include_once '../models/Product.php';

use Database\Database;
use Models\Product;

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

if (isset($_GET['id'])) {
    $product->id = htmlspecialchars(strip_tags($_GET['id']));
    
    // Lógica para eliminar el producto usando PHP puro sin confirmación en el servidor
    if ($product->delete()) {
        echo "<script>
                alert('Producto eliminado correctamente.');
                window.location.href = '../views/list_products.php';
              </script>";
    } else {
        echo "<script>
                alert('No se pudo eliminar el producto.');
                window.location.href = '../views/list_products.php';
              </script>";
    }
} else {
    // Si no hay 'id', redirigir al usuario a la página principal
    echo "<script>window.location.href = '../index.php';</script>";
}
?>
