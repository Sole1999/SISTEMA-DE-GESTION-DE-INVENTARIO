<?php
// Eliminar Categoría
include_once '../database/Database.php';
include_once '../models/Supplier.php';

use Database\Database;
use Models\Supplier;

$database = new Database();
$db = $database->getConnection();
$supplier = new Supplier($db);

if (isset($_GET['id'])) {
    $supplier->id = htmlspecialchars(strip_tags($_GET['id']));

    if ($supplier->delete()) {
        echo "<script>
                alert('Proveedor eliminado correctamente.');
                window.location.href = '../views/list_suppliers.php';
              </script>";
    } else {
        echo "<script>
                alert('No se pudo eliminar el proveedor.');
                window.location.href = '../views/list_suppliers.php';
              </script>";
    }
} else {
    // Si no hay 'id', redirigir al usuario a la página principal
    echo "<script>window.location.href = '../index.php';</script>";
}

?>