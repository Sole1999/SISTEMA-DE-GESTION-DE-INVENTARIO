<?php
// 8. Agregar Producto (Archivo: views/add_product.php)
include_once "../database/Database.php";
include_once "../models/Product.php";
include_once "../models/Category.php";

use Database\Database;
use Models\Product;
use Models\Category;

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);
$category = new Category($db);

$stmt = $category->readAll();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product->name = htmlspecialchars(strip_tags($_POST['name']));
    $product->quantity = htmlspecialchars(strip_tags($_POST['quantity']));
    $product->price = htmlspecialchars(strip_tags($_POST['price']));
    $product->category_id = htmlspecialchars(strip_tags($_POST['category_id']));


    $categoryAddedSuccessfully = $product->create();

    if ($categoryAddedSuccessfully) {
        header("Location: ../views/list_products.php?success=1");
        exit();
    } else {
        echo "<p>Error al agregar el producto</p>";
    }
}
?>

<?php include_once "../partials/header.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Producto</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include_once "../partials/menu_actions.php"; ?>

    <div id="content" class="container-fluid">

        <div id="content" class="container mt-1 ml-1">
            <h2 class="mb-4">Agregar Producto</h2>
            <div class="card mt-4">
                <div class="card-body">
                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="name">Nombre del Producto</label>
                            <input type="text" name="name" id="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="quantity">Cantidad</label>
                            <input type="number" name="quantity" id="quantity" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="price">Precio</label>
                            <input type="number" step="0.01" name="price" id="price" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Categoría</label>
                            <select name="category_id" id="category_id" class="form-control" required>
                                <!-- Aquí se podrían agregar opciones dinámicas desde la base de datos -->
                                <option value="">Seleccione una categoría</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo htmlspecialchars($category['id']); ?>">
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Agregar Producto</button>
                        <a href="../views/list_products.php" class="btn btn-secondary">Regresar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<br>
<br>
<br>
<?php include_once "../partials/footer.php"; ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</html>
