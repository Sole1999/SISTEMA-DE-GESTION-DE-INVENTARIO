<?php
require '../vendor/autoload.php';
include_once '../database/Database.php';
include_once '../models/Supplier.php';

use Database\Database;
use Models\Supplier;
use Dompdf\Dompdf;

$database = new Database();
$db = $database->getConnection();
$supplier = new Supplier($db);

$stmt = $supplier->readAll();

$html = '<h1>Lista de Proveedores</h1>';
$html .= '<table border="1" cellpadding="10" cellspacing="0">';
$html .= '<thead><tr><th>Nombre del Proovedor</th><th>Información de Contacto</th></tr></thead><tbody>';

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $html .= '<tr><td>' . $row['name'] . '</td><td>' . $row['contact_info'] . '</td></tr>';
}

$html .= '</tbody></table>';

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('Lista_de_Proveedores' . date('Ymd_His') . '.pdf');
?>
