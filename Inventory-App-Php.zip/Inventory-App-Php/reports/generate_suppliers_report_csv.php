
<?php
include_once "../database/Database.php";
include_once "../models/Supplier.php";

use Database\Database;
use Models\Supplier;

$database = new Database();
$db = $database->getConnection();
$supplier = new Supplier($db);

$stmt = $supplier->readAll();
$filename = "reports/Lista_de_Proveedores" . date('Ymd_His') . ".csv";

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . basename($filename) . '"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Proveedor', 'Contacto']);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [$row['name'], $row['contact_info']]);
}

fclose($output);
?>
