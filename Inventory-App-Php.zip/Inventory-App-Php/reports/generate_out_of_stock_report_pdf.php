<?php
require '../vendor/autoload.php';
include_once '../database/Database.php';
include_once '../models/Product.php';

use Database\Database;
use Models\Product;
use Dompdf\Dompdf;

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

$stmt = $product->getOutOfStock();

$html = '<h1>Reporte de Productos Agotados</h1>';
$html .= '<table border="1" cellpadding="10" cellspacing="0">';
$html .= '<thead><tr><th>ID</th><th>Nombre</th><th>Cantidad</th><th>Categoría</th></tr></thead><tbody>';

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $html .= '<tr><td>' . $row['id'] . '</td><td>' . $row['name'] . '</td><td>' . $row['quantity'] . '</td><td>' . $row['category_name'] . '</td></tr>';
}

$html .= '</tbody></table>';

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('out_of_stock_report_' . date('Ymd_His') . '.pdf');
?>
