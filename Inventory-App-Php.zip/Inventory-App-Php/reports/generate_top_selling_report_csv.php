<?php

require '../vendor/autoload.php';
include_once '../database/Database.php';
include_once '../models/Sale.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;

use Database\Database;
use Models\Sale;

$database = new Database();
$db = $database->getConnection();
$sale = new Sale($db);

$stmt = $sale->getTopSelling();

// Crear una nueva hoja de cálculo
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Productos Más Vendidos');

// Encabezados
$sheet->setCellValue('A1', 'Nombre del Producto');
$sheet->setCellValue('B1', 'Cantidad Vendida');
$sheet->setCellValue('C1', 'Categoría');

// Aplicar estilo a los encabezados
$headerStyle = [
    'font' => [
        'bold' => true,
        'color' => ['argb' => Color::COLOR_WHITE],
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['argb' => '4CAF50'], // Verde
    ],
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['argb' => Color::COLOR_BLACK],
        ],
    ],
];
$sheet->getStyle('A1:C1')->applyFromArray($headerStyle);

// Datos
$rowIndex = 2;
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $sheet->setCellValue('A' . $rowIndex, $row['product_name']);
    $sheet->setCellValue('B' . $rowIndex, $row['total_sold']);
    $sheet->setCellValue('C' . $rowIndex, $row['category_name']);

    // Aplicar bordes a las celdas de datos
    $sheet->getStyle('A' . $rowIndex . ':C' . $rowIndex)->applyFromArray([
        'borders' => [
            'allBorders' => [
                'borderStyle' => Border::BORDER_THIN,
                'color' => ['argb' => Color::COLOR_BLACK],
            ],
        ],
    ]);

    $rowIndex++;
}

// Guardar el archivo Excel
$writer = new Xlsx($spreadsheet);
$filePath = 'top_selling_report_' . date('Ymd_His') . '.xlsx';
$writer->save($filePath);

echo "Reporte Excel generado correctamente: $filePath";

/*include_once "../database/Database.php";
include_once "../models/Sale.php";

use Database\Database;
use Models\Sale;

$database = new Database();
$db = $database->getConnection();
$sale = new Sale($db);

// Función para generar el reporte CSV con soporte UTF-8
function generateTopSellingReportCSV($sale) {
    $stmt = $sale->getTopSelling();
    $filename = "reports/top_selling_report_" . date('Ymd_His') . ".csv";

    $file = fopen($filename, 'w');
    
    // Añadir BOM para soportar caracteres especiales
    fputs($file, $bom = (chr(0xEF) . chr(0xBB) . chr(0xBF)));

    // Encabezados
    fputcsv($file, ['Nombre del Producto', 'Cantidad Vendida', 'Categoría']);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($file, [$row['product_name'], $row['total_sold'], $row['category_name']]);
    }
    fclose($file);
}*/

/*$stmt = $sale->getTopSelling();
$filename = "reports/top_selling_report_" . date('Ymd_His') . ".csv";

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . basename($filename) . '"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Nombre del Producto', 'Cantidad Vendida', 'Categoría']);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [$row['product_name'], $row['total_sold'], $row['category_name']]);
}

fclose($output);*/
?>
