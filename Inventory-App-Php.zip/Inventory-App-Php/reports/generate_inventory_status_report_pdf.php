<?php
require '../vendor/autoload.php';
include_once '../database/Database.php';
include_once '../models/Product.php';

use Database\Database;
use Models\Product;
use Dompdf\Dompdf;

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

$stmt = $product->getInventoryStatus();

$html = '<h1>Reporte del Estado General del Inventario</h1>';
$html .= '<table border="1" cellpadding="10" cellspacing="0">';
$html .= '<thead><tr><th>Nombre</th><th>Cantidad</th><th>Precio</th><th>Categoría</th></tr></thead><tbody>';

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $html .= '<tr><td>' . $row['name'] . '</td><td>' . $row['quantity'] . '</td><td>' . $row['price'] . '</td><td>' . $row['category_name'] . '</td></tr>';
}

$html .= '</tbody></table>';

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('inventory_status_report_' . date('Ymd_His') . '.pdf');
?>
