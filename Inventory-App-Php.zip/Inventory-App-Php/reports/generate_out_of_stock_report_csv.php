<?php
include_once "../database/Database.php";
include_once "../models/Product.php";

use Database\Database;
use Models\Product;

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

$stmt = $product->getOutOfStock();
$filename = "reports/out_of_stock_report_" . date('Ymd_His') . ".csv";

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . basename($filename) . '"');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'Nombre', 'Cantidad', 'Categoría']);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [$row['id'], $row['name'], $row['quantity'], $row['category_name']]);
}

fclose($output);
?>
