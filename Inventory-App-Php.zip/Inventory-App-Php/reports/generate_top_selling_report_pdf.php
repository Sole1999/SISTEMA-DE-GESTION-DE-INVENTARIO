<?php
require '../vendor/autoload.php';
include_once '../database/Database.php';
include_once '../models/Sale.php';

use Database\Database;
use Models\Sale;
use Dompdf\Dompdf;

$database = new Database();
$db = $database->getConnection();
$sale = new Sale($db);

$stmt = $sale->getTopSelling();

$html = '<h1>Reporte de Productos Más Vendidos</h1>';
$html .= '<table border="1" cellpadding="10" cellspacing="0">';
$html .= '<thead><tr><th>Nombre del Producto</th><th>Cantidad Vendida</th><th>Categoría</th></tr></thead><tbody>';

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $html .= '<tr><td>' . $row['product_name'] . '</td><td>' . $row['total_sold'] . '</td><td>' . $row['category_name'] . '</td></tr>';
}

$html .= '</tbody></table>';

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('top_selling_report_' . date('Ymd_His') . '.pdf');
?>
